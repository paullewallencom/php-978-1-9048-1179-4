<?php
define('SCHEDULE_MOVIE', 19);
define('ADD_MOVIE', 18);
?>