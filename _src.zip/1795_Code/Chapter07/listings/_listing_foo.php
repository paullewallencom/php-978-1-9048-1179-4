<?php

require_once 'Date.php';
require_once 'Date/TimeZone.php';

$date = new Date('2005-12-24 12:00:00');



?>
