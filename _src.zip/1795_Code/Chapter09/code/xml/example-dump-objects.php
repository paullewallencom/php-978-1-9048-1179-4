<?php
require_once 'example-create-objects.php';
echo '<pre>';
print_r($labels);
echo '</pre>';
?>